package com.sina.weibo.sdk.demo;

/**
 * Created by zxs on 2017/1/10.
 */

public class BaseApiOpen extends BaseApi{
}
