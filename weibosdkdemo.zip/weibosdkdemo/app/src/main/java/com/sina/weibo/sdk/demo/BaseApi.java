package com.sina.weibo.sdk.demo;

/**
 * Created by zxs on 2017/1/10.
 */

public class BaseApi {
    public static String OpenName = "aaaaaa";
}
