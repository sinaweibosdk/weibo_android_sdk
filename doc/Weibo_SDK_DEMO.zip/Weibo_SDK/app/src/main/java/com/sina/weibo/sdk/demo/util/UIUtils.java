package com.sina.weibo.sdk.demo.util;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;

import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.annotation.NonNull;

/**
 * Created by kang on 2025/8/19.
 */
public class UIUtils {
    public static void setContentViewAndSetWindowInsets(Activity activity, int layout) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            activity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        Context context;
        View view = LayoutInflater.from(activity).inflate(layout, null);
        if ((context = view.getContext()) != null && Build.VERSION.SDK_INT >= 35 && context.getApplicationInfo().targetSdkVersion >= 35) {
            ViewCompat.setOnApplyWindowInsetsListener(view, new OnApplyWindowInsetsListener() {
                @Override
                public @NonNull WindowInsetsCompat onApplyWindowInsets(@NonNull View v, @NonNull WindowInsetsCompat windowInsets) {
                    Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
                    v.setPadding(insets.left, insets.top, insets.left, insets.bottom);
                    return WindowInsetsCompat.CONSUMED;
                }
            });
        }
        activity.setContentView(view);
    }
}
