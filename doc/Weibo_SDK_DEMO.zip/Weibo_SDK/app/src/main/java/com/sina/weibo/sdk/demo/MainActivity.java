package com.sina.weibo.sdk.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.sina.weibo.sdk.auth.Oauth2AccessToken;
import com.sina.weibo.sdk.auth.WbAuthListener;
import com.sina.weibo.sdk.common.UiError;
import com.sina.weibo.sdk.demo.util.UIUtils;
import com.sina.weibo.sdk.openapi.IWBAPI;
import com.sina.weibo.sdk.openapi.WBAPIFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity implements View.OnClickListener {
    private Button mInit;

    private Button mSso;

    private Button mClientSso;

    private Button mWebSso;

    private Button mClientShare;

    private IWBAPI mWBAPI;

    private static String LOG_TAG = "WEIBO_SDK_TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UIUtils.setContentViewAndSetWindowInsets(this, R.layout.activity_main);
        mInit = findViewById(R.id.init_sdk);
        mSso = findViewById(R.id.sso);
        mClientSso = findViewById(R.id.sso_client);
        mWebSso = findViewById(R.id.sso_web);
        mInit.setOnClickListener(this);
        mSso.setOnClickListener(this);
        mClientSso.setOnClickListener(this);
        mWebSso.setOnClickListener(this);
        mClientShare = findViewById(R.id.share_client);
        mClientShare.setOnClickListener(this);
        copy();
        if (savedInstanceState != null && savedInstanceState.getBoolean("sdk_init")) {
            initSdk();
        }
    }

    //init sdk
    private void initSdk() {
        mWBAPI = WBAPIFactory.createWBAPI(this);
        mSso.setEnabled(true);
        mClientSso.setEnabled(true);
        mWebSso.setEnabled(true);
    }

    private void startAuth() {
        //auth
        mWBAPI.authorize(this, new WbAuthListener() {
            @Override
            public void onComplete(Oauth2AccessToken token) {
                Toast.makeText(MainActivity.this, "微博授权成功", Toast.LENGTH_SHORT).show();
                Log.d(LOG_TAG, "授权成功：uid=" + token.getUid() + "; token=" + token.getAccessToken());
            }

            @Override
            public void onError(UiError error) {
                Toast.makeText(MainActivity.this, "微博授权出错", Toast.LENGTH_SHORT).show();
                Log.d(LOG_TAG, "微博授权出错：" + error.errorMessage + "-" + error.errorDetail);
            }

            @Override
            public void onCancel() {
                Toast.makeText(MainActivity.this, "微博授权取消", Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mWBAPI.isAuthorizeResult(requestCode, resultCode, data)) {
            mWBAPI.authorizeCallback(this, requestCode, resultCode, data);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == mInit) {
            initSdk();
        }
        if (v == mSso) {
            try {
                startAuth();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        if (v == mClientSso) {
            try {
                startClientAuth();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        if (v == mWebSso) {
            try {
                startWebAuth();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        if (v == mClientShare) {
            Intent intent = new Intent(MainActivity.this, ShareActivity.class);
            startActivity(intent);
        }
    }

    private void startClientAuth() {
        mWBAPI.authorizeClient(this, new WbAuthListener() {
            @Override
            public void onComplete(Oauth2AccessToken token) {
                Toast.makeText(MainActivity.this, "微博授权成功", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onError(UiError error) {
                Toast.makeText(MainActivity.this, "微博授权出错", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancel() {
                Toast.makeText(MainActivity.this, "微博授权取消", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startWebAuth() {
        mWBAPI.authorizeWeb(this, new WbAuthListener() {
            @Override
            public void onComplete(Oauth2AccessToken token) {
                Toast.makeText(MainActivity.this, "微博授权成功", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(UiError error) {
                Toast.makeText(MainActivity.this, "微博授权出错:" + error.errorDetail, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancel() {
                Toast.makeText(MainActivity.this, "微博授权取消", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void copy() {
        File externalFilesDir = getExternalFilesDir(null);
        File externalCacheDir = getExternalCacheDir();
        copyFile("eeee.mp4", new File(externalFilesDir, "file_video"));
        copyFile("aaa.png", externalFilesDir);
        copyFile("bbb.jpg", externalCacheDir);
        copyFile("ccc.JPG", new File(externalFilesDir, "file_images"));
        copyFile("ddd.jpg", new File(externalFilesDir, "cache_images"));
        copyFile("eee.jpg", new File(externalCacheDir, "file_images"));
        copyFile("fff.jpg", new File(externalFilesDir, "file_images"));
        copyFile("ggg.JPG", new File(externalFilesDir, "file_images"));
        copyFile("hhhh.jpg", new File(externalFilesDir, "file_images"));
        copyFile("kkk.JPG", new File(externalFilesDir, "file_images"));
    }

    private void copyFile(final String fileName, File fileDir) {
        if (!fileDir.exists()) {
            fileDir.mkdirs();
        }
        final File file = new File(fileDir, fileName);
        if (!file.exists()) {
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try (InputStream inputStream = getAssets().open(fileName);
                         OutputStream outputStream = new FileOutputStream(file)) {
                        byte[] buffer = new byte[1444];
                        int readSize;
                        while ((readSize = inputStream.read(buffer)) != 0) {
                            outputStream.write(buffer, 0, readSize);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("sdk_init", mWBAPI != null);
    }
}
